const express = require("express");
const { signUpController,signInController, signOut } = require("../controller/auth.controller");

const router = express.Router();

router.post("/signup",signUpController);
router.post("/login",signInController);
router.get('/signout', signOut)




module.exports = router;