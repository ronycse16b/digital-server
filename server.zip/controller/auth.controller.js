const bcryptjs = require("bcryptjs");
const UserModel = require("../models/user.model");
const jwt = require("jsonwebtoken");


const signUpController = async (req, res) => {
  const { name, email, password, security } = req.body;
  const hashPassword = bcryptjs.hashSync(password, 10);
  const newUser = new UserModel({
    name,
    email,
    password: hashPassword,
    security,
  });

  const registerUserCheck = await UserModel.findOne({email})
  if(registerUserCheck)
  {
    return res.send('Email is already registered')
  }

  try {
    await newUser.save();
    res.status(201).json({
      success: true,
      message: "Signup Successfully",
    });
  } catch (error) {
    console.log(error.message);
  }
};

const signInController = async (req, res) => {

  const { email, password } = req.body;
  try {
    const validUser = await UserModel.findOne({ email });
    if (!validUser) {
        return res.status(402).json({
            success:false,
            message:'wrong email'
          });
    }
    
    const validPassword = bcryptjs.compareSync(password, validUser.password);
    if (!validPassword) {
      return res.status(402).json({
        success:false,
        message:'wrong credentials'
      });
    }

    const token = jwt.sign({ _id: validUser._id }, process.env.JWT_SECRET, { expiresIn: '4h' });
    console.log(token);

    const { password: pass, security:secu, ...data } = validUser._doc || {};

    res
      .cookie('access_token', token, { httpOnly: true })
      .status(200)
      .json({data,
    message:"Sign-in Successful"});


  } catch (error) {
    console.log(error);
  }
};

const signOut = async (req, res, next) => {
    try {
      res.clearCookie('access_token');
      res.status(200).json('User has been logged out!');
    } catch (error) {
      next(error);
    }
  };




module.exports = { signUpController, signInController,signOut };
