const TaxModel = require("../models/tax.register.model");
const WardDataModel = require("../models/ward.data.model");
const WardModel = require("../models/ward.model");

// ward get data
const wardGetDataController = async (req, res) => {
  try {
    const wards = await WardModel.find({});
    if (wards.length > 0) {
      res.status(200).send({ success: true, message: "all-wards", wards });
    } else {
      res.status(200).send([""]);
    }
  } catch (error) {
    console.log(error.message);
  }
};

// create ward data
const wardDataMakeController = async (req, res) => {
  try {
    const { birthRegNumber, nidNumber } = req.body;

    if (!birthRegNumber && !nidNumber) {
      return res.send("Either Birth Reg Number or Nid Number must be provided");
    }

    const newData = req.body;

    const wardDataInstance = new WardDataModel(newData);
    const savedData = await wardDataInstance.save();

    res.status(201).json({ message: "Data Created Successfully", savedData });
  } catch (error) {
    console.error(error.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// get wards data

const wardWaysDataController = async (req, res) => {
  try {
    const ward = req.params.id;

    const data = await WardDataModel.find({ ward: ward });
    res.status(200).send({
      success: true,
      countTotal: data.length,
      message: "All Ward Ways Data ",
      data,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Error Ward data ",
    });
  }
};

// all data show
const getDataController = async (req, res) => {
  try {
    const id = req.params.id;
    console.log(id);
    const page = parseInt(req.query.page) || 1;
    const perPage = parseInt(req.query.perPage) || 20;

    const countTotal = await WardDataModel.countDocuments({ ward: id });
    const totalPages = Math.ceil(countTotal / perPage);
    const skip = (page - 1) * perPage;

    const data = await WardDataModel.find({ ward: id })
      .skip(skip)
      .limit(perPage)
      .populate("ward");

    res.status(200).send({
      success: true,
      countTotal,
      totalPages,
      currentPage: page,
      perPage,
      message: "Data fetched successfully",
      data,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Error in getting data",
    });
  }
};


const fullDataController = async (req, res) => {
  try {
    const data = await WardDataModel.find({}).populate("ward");
    if (data.length > 0) {
      res.status(200).send({ success: true, message: "all-data", data });
    } else {
      res.status(200).send([""]);
    }
  } catch (error) {
    console.log(error.message);
  }
};







const searchDataController = async (req, res) => {
  try {
    const { wardNumber, searchValue } = req.query;

    const data = await WardDataModel.findOne({
      ward: wardNumber,
      holding: searchValue,
    }).populate("ward"); // Assuming there's a reference to another model named 'ward'

    res.json(data);
  } catch (error) {
    console.error(error);
    res
      .status(500)
      .json({ error: "Error searching for data", details: error.message });
  }
};

const taxPaymentController = async (req, res) => {
  try {
    const { year, paymentId, cor } = req.body;

    const taxPayment = await TaxModel(req.body).save();

    if (taxPayment) {
      // Update the WardDataModel by pushing the tax payment object into the checkbox array
      const wardData = await WardDataModel.findOne({ _id: paymentId });

      if (wardData) {
        wardData.checkbox.push({
          year,
          cor,
        });

        await wardData.save();

        await taxPayment.populate("user");
        return res.status(200).json({
          message: "Payment Successfully",
          taxPayment,
        });
      } else {
        return res.status(404).json({
          message: "Ward data not found for the user.",
        });
      }
    }
  } catch (error) {
    console.error(error.message);
    return res.status(500).json({
      message: "Internal Server Error",
      error: error.message,
    });
  }
};

const DataViewControllerByQRCode = async (req, res) => {
 try {
  const dataId = req.params.id;


  const view = await WardDataModel.findOne({ _id: dataId }).populate("ward");
  if (view) {
    res.status(200).send(view);
  }
  
 } catch (error) {
  console.log(error.message);
 }
};

const paymentViewControllerByQRCode = async (req, res) => {
  try {
    const taxId = req.params.taxId;


  const view = await TaxModel.findOne({ sn: taxId }).populate("ward");
  if (view) {
    const taxView = await view.populate('user')
    res.status(200).send(taxView);
  }
  } catch (error) {
    console.log(error);
  }
};

const TaxRegisterGetDataController = async (req, res) => {
  try {
    const taxRegister = await TaxModel.find({});
    if (taxRegister) {
      res.status(200).send({ message: "tax Register Data ", taxRegister });
    }
  } catch (error) {
    console.log(error.message);
  }
};

module.exports = {
  wardGetDataController,
  wardDataMakeController,
  wardWaysDataController,
  getDataController,
  searchDataController,
  taxPaymentController,
  TaxRegisterGetDataController,
  DataViewControllerByQRCode,
  paymentViewControllerByQRCode,
  fullDataController
 
};
