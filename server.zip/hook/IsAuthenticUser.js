const jwt = require("jsonwebtoken");

const IsAuthenticUser = (req, res, next) => {
  const token = req.cookies.access_token;
console.log(token);
  if (!token) {
    return res.status(403).send({message: 'Unauthorized'});
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).send({message: 'Forbidden', error: err});
    }
    req.user = user;
    next();
  });
};

module.exports = IsAuthenticUser;
