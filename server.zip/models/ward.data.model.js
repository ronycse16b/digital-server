const mongoose = require('mongoose');

const wardDataSchema = new mongoose.Schema(
  {
    birthRegNumber: {
      type: String,
      default:"-"
    },
    union: {
      type: String,
      default:"৮নং লাকসাম পূর্ব ইউনিয়ন পরিষদ"
    },
    cor: {
      type: Number,
      required: true
    },
    dateOfBirth: {
      type: Date,
      required: true
    },
    fatherName: {
      type: String,
      required: true
    },
    female: {
      type: Number,
      required: true
    },
    holding: {
      type: Number,
      required: true
    },
    house: {
      type: String,
      required: true
    },
    houseName: {
      type: String,
      required: true
    },
    male: {
      type: Number,
      required: true
    },
    marriedStatus: {
      type: String,
      required: true
    },
    mobile: {
      type: Number,
      required: true
    },
    motherName: {
      type: String,
      required: true
    },
    name: {
      type: String,
      required: true
    },
    nidNumber: {
      type: String,
      default:"-"
    },
    profession: {
      type: String,
      required: true
    },
    villageName: {
      type: String,
      required: true
    },
    qrCode:{
        type:String,
    },
    ward: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "wards", // Referencing the 'wards' collection
      required: true,
    },
    yearMullayon: {
      type: String,
      required: true
    },
    checkbox: [],
    
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "users", // Referencing the 'users' collection
      required: true,
    },
  },
  {
    timestamps: true
  }
);

const WardDataModel = mongoose.model("ward-data", wardDataSchema);
module.exports = WardDataModel;
